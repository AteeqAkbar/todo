import React from "react";
import CalendarComponent from "../components/FullCalendar";

const Events = () => {
  return (
    <>
      <CalendarComponent />
    </>
  );
};

export default Events;
